export const constants = {
    NO_MODIFY: "未修改",
    USER_ID_KEY: "userId",
    IS_LOGIN_KEY: "isLogin",
    NO_PERMIS: "无权限",
    INIT_STATE: "INIT_STATE",
    SAVE_STORE_KEY: "SAVE_STORE_KEY",
    USER_INFO_KEY: "USER_INFO_KEY",
    USER_TOKEN: "USER_TOKEN"
};