export const LOGIN = "login";
export const LOGIN_FAIL = "LOGIN_FAIL";
export const LOGOUT = "loginout";

export const TITLE = "title";