<template>
  <div class="list">
      <ul>
        <li>这是第二页</li>
      </ul>
  </div>
</template>
<script>
export default {
  name: "list"
};
</script>
<style>

</style>
