<template>
  <div id="app">

  <transition>
    <keep-alive>
      <router-view></router-view>
    </keep-alive>
  </transition>

  </div>
</template>

<script>
export default {
  name: 'app'
}
</script>

<style>
@import 'css/reset.css';
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
</style>
